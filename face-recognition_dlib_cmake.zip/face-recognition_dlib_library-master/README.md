# face-recognition_dlib_library
Installing dlib library file in windows 10 
